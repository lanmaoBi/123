import pickle
import numpy as np
import os

sub_list = ['000', '036', '051', '054']

all_data = []
all_labels = []

for i in sub_list:

    path = fr"D:\wangyiwu\FACED\Processed_data\Processed_data\sub{i}.pkl"
    with open(path, 'rb') as file:
        x = pickle.load(file)
    print(x.shape)  # (28, 32, 7500)

    seq_len = x.shape[-1]
    fs = 250
    window_size = fs * 3
    step = 25
    num = (seq_len - window_size) // step + 1

    divided_data = []
    for i in range(0, num * step, step):
        segment = x[:, :, i: (i + window_size)]
        divided_data.append(segment)
    x = np.stack(divided_data, axis=2)
    print(x.shape)

    anger = x[0:3].transpose(0, 2, 1, 3).reshape(-1, x.shape[1], x.shape[3])
    print('anger', anger.shape)  # anger (30, 32, 750)
    disgust = x[3:6].transpose(0, 2, 1, 3).reshape(-1, x.shape[1], x.shape[3])
    sadness = x[9:12].transpose(0, 2, 1, 3).reshape(-1, x.shape[1], x.shape[3])
    joy = x[22:25].transpose(0, 2, 1, 3).reshape(-1, x.shape[1], x.shape[3])

    x = np.vstack([anger, disgust, sadness, joy])
    print(x.shape)  # (120, 32, 750)

    labels = np.array([0, 1, 2, 3])   # [anger, disgust, sadness, joy]
    repeats = anger.shape[0]
    labels = np.repeat(labels, repeats, axis=0)
    print(labels.shape)  # (120,)
    all_data.append(x)
    all_labels.append(labels)

all_data = np.vstack(all_data)
all_labels = np.concatenate(all_labels)

save_path = 'D:/wangyiwu/FACED/Processed_data/'

with open(os.path.join(save_path, "all_data.pkl"), "wb") as f:
    pickle.dump(all_data, f)

with open(os.path.join(save_path, "all_labels.pkl"), "wb") as f:
    pickle.dump(all_labels, f)


