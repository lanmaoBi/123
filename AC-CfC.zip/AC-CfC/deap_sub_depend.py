import torch
import torch.nn as nn
from numpy import *
import scipy.io as sio
import numpy as np
import torch

import torch.optim as optim
from torch.utils.data import DataLoader
from data_loader import GetLoader
# from dcnn_Cfc import ConvCfc

from sklearn.model_selection import train_test_split

import pickle
import pandas as pd
import datetime
import time
import matplotlib.pyplot as plt
from pytorchtools import EarlyStopping
from sklearn.metrics import accuracy_score
from model import *



class WeightedCrossEntropyLoss(nn.Module):
    def __init__(self, weight=None):
        super(WeightedCrossEntropyLoss, self).__init__()
        self.weight = weight

    def forward(self, inputs, targets):
        ce_loss = nn.CrossEntropyLoss(weight=self.weight)
        return ce_loss(inputs, targets)


def normalize(data):
    '''
    min_max_scaler = preprocessing.MinMaxScaler(feature_range=(-1, 1))
    data = min_max_scaler.fit_transform(data)
    '''
    data -= np.mean(data, axis=0)
    data /= np.std(data, axis=0)
    return data

def Entropy(input_):
    bs = input_.size(0)
    epsilon = 1e-5
    entropy = -input_ * torch.log(input_ + epsilon)
    # entropy = torch.sum(entropy, dim=1)
    return entropy

def deap_preprocess(subject, dimention):
    # set the file type and path
    rnn_suffix = ".mat_win_384_rnn_dataset.pkl"
    label_suffix = ".mat_win_384_labels.pkl"
    arousal_or_valence = dimention
    with_or_without = 'yes'
    dataset_dir = "D:/wangyiwu/pyreject/AC-CfC/deap_shuffled_data_3s__/" + with_or_without + "_" + arousal_or_valence + "/"
    with open(dataset_dir + subject + rnn_suffix, "rb") as fp:
        rnn_datasets = pickle.load(fp)
    with open(dataset_dir + subject + label_suffix, "rb") as fp:
        labels = pickle.load(fp)
        labels = np.transpose(labels)
    # print("loaded shape:",labels.shape)
    # lables_backup = labels
    # one_hot_labels = np.array(list(pd.get_dummies(labels)))
    #[1,0]
    # labels = np.asarray(pd.get_dummies(labels), dtype=np.int8)
    labels = np.asarray(labels, dtype=np.int8)

    # shuffle data
    index = np.array(range(0, len(labels)))
    np.random.shuffle(index)
    rnn_datasets = rnn_datasets[index]  # .transpose(0,2,1)
    labels = labels[index]
    datasets = rnn_datasets

    datasets = datasets.astype('float32')
    # labels = labels.astype('float32')

    split_ratio = 0.2
    train_data, test_data, train_labels, test_labels = train_test_split(datasets, labels, test_size=1 - split_ratio,
                                                                        random_state=42)

    #input_train = input_train.reshape((-1, 310))
    #input_test = input_test.reshape((-1, 310))
    print(train_data.shape)
    print(test_data.shape)
    print(train_labels.shape)
    print(test_labels.shape)

    return train_data, test_data, train_labels, test_labels
    # return datasets, labels

def model_train(model, train_dataloader, epoch, model_path, bs, val_dataloader):
    len_train = len(train_dataloader)
    early_stopping = EarlyStopping(patience=3, verbose=True, path=model_path)

    for e in range(epoch):
        model.train()  # 设置模型为训练模式
        running_loss = []
        temperature = 2

        softmax_layer = nn.Softmax(dim=1)
        criterion = nn.CrossEntropyLoss()
        # optimizer = optim.SGD(model.parameters(), lr=0.001)
        # optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.9, weight_decay=1e-6)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-6)
        schedule = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=5, T_mult=2, eta_min=1e-5)

        for batch_idx, (inputs, labels) in enumerate(train_dataloader):

            labels = labels.long()
            inputs = inputs.float()
            # print(inputs.shape)

            optimizer.zero_grad()  # 清空梯度

            # channel_attention = ChannelAttention(inputs.size(1), inputs.size(2))
            # inputs = channel_attention(inputs)

            outputs, _ = model(inputs)
            ''''''
            output = outputs / temperature
            output_temp = softmax_layer(output)
            output_entropy_weight = Entropy(output_temp).detach()  #H
            output_entropy_weight = 1 + torch.exp(-output_entropy_weight)
            output_entropy_weight = bs * output_entropy_weight / torch.sum(output_entropy_weight)  #W
            output_entropy_weight = output_entropy_weight.mean(dim=0)
            # print(output_entropy_weight)
            criterion = WeightedCrossEntropyLoss(weight=output_entropy_weight)
            # cov_matrix_t = output_temp.mul(output_entropy_weight.view(-1, 1)).transpose(1, 0).mm(output_temp)   #C
            # # cov_matrix_t = target_softmax_out_temp.transpose(1, 0).mm(target_softmax_out_temp)
            # cov_matrix_t = cov_matrix_t / torch.sum(cov_matrix_t, dim=1)
            # mcc_loss = (torch.sum(cov_matrix_t) - torch.trace(cov_matrix_t)) / 2
            # # print(mcc_loss)
            # loss = mcc_loss
            # mcc_loss.backward()
            # optimizer.step()

            ''''''
            loss = criterion(outputs, labels)
            # # print(loss)
            # loss = loss + mcc_loss
            #
            # loss = mcc_loss
            loss.backward()
            optimizer.step()
            schedule.step()

            # loss = loss + mcc_loss
            running_loss.append(loss.item())

        running_loss = np.average(running_loss)
        print(f"Epoch {e+1}/{epoch} - Loss: {running_loss}")

        # Validation
        model.eval()
        model.eval()
        val_loss = 0.0
        val_predictions = []
        val_targets = []
        with torch.no_grad():
            for val_inputs, val_labels in val_dataloader:
                val_labels = val_labels.long()
                val_inputs = val_inputs.float()
                val_outputs, _ = model(val_inputs)
                val_batch_loss = criterion(val_outputs, val_labels)
                val_loss += val_batch_loss.item()
                val_preds = torch.argmax(val_outputs, dim=1)
                val_predictions.extend(val_preds.cpu().numpy())
                val_targets.extend(val_labels.cpu().numpy())

        val_loss /= len(val_dataloader)
        val_accuracy = accuracy_score(val_targets, val_predictions)  # Calculate accuracy
        print(f"Validation Loss: {val_loss:.6f} - Val_accuracy: {val_accuracy:.4f}")

        early_stopping(val_loss, model)

        if early_stopping.early_stop:
            print("Early stopping")
            break
    torch.save(model.state_dict(), model_path)

def model_test(model, test_dataloader):
    model.eval()
    correct = 0
    total = 0
    softmax_layer = nn.Softmax(dim=1)

    with torch.no_grad():
        for inputs, labels in test_dataloader:
            labels = labels.long()
            inputs = inputs.float()
            outputs, _ = model(inputs)
            outputs = softmax_layer(outputs)
            _, predicted = torch.max(outputs.data, 1)

            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = correct / total
    print(f"Accuracy: {accuracy * 100}%")
    return accuracy

if __name__ == '__main__':
    EPOCHS = 30
    # DOMAIN_THRSH = 0.3
    BATCH_SIZE = 32
    # criterion = nn.CrossEntropyLoss()
    # criterion = WeightedCrossEntropyLoss()
    acc = []

    for sub_id in range(1, 32):
        print("processing ", sub_id)
        dimention = 'valence'  # arousal/'valence'
        sub_id = "%02d" % sub_id
        sub = "s" + str(sub_id)
        train_x, test_x, train_y, test_y = deap_preprocess(sub, dimention)

        train_x = train_x.transpose(0, 2, 1)
        test_x = test_x.transpose(0, 2, 1)
        # Assuming your data is in X_train, y_train, X_val, y_val format
        X_train, X_val, y_train, y_val = train_test_split(train_x, train_y, test_size=0.2, random_state=42)
        # print(train_y)
        # print(test_y)

        train_dataset = GetLoader(train_x, train_y)
        val_dataset = GetLoader(X_val, y_val)
        test_dataset = GetLoader(test_x, test_y)
        train_dataloader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
        val_dataloader = DataLoader(dataset=val_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
        test_dataloader = DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
        # print(train_dataloader)
        model = ConvCfc()
        model_path = 'models_deap/best_model{0}.pth'.format(sub_id)
        model_train(model, train_dataloader, EPOCHS, model_path, BATCH_SIZE, val_dataloader)

        model.load_state_dict(torch.load(model_path))
        accuracy = model_test(model, test_dataloader)
        acc.append(accuracy)

    acc = np.array(acc)
    print(np.mean(acc))
    print(np.std(acc))