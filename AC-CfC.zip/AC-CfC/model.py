
import torch.nn as nn
from torch_cfc import Cfc
import torch



class CAM(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CAM, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, 32, bias=False),
            nn.Tanh(),
            nn.Linear(32, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1)
        weighted_x = x * y.expand_as(x)
        y_ = y.reshape(b, c)
        return weighted_x,  y_


class ConvCfc(nn.Module):
    def __init__(self, ):
        super(ConvCfc, self).__init__()
        self.channel_attention = CAM(32)  # Add ChannelAttention layer   #DEAP:32,DREAMER :14
        self.conv = nn.Conv1d(in_channels=32, out_channels=32, kernel_size=3, padding=1)   #DEAP:32,DREAMER :14
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2)
        self.dropout = nn.Dropout(p=0.2)
        hparams = {"backbone_activation": "silu",
                   "backbone_units": 64, "backbone_layers": 2, "backbone_dr": 0.5, "tau": 10,
                   "init": 1.35, "use_mixed": True, "no_gate": False, "minimal": False}
        self.cfc = Cfc(in_features=192, hidden_size=64, out_feature=2, hparams=hparams, return_sequences=False)

    def forward(self, input):
        # Apply the ChannelAttention to the input
        attention_output, y = self.channel_attention(input)

        output_ = self.conv(attention_output)
        output_ = self.pool(output_)
        output_ = self.dropout(output_)

        # Pass through the Cfc layer
        output = self.cfc(output_)

        return output, y



class faced_train(nn.Module):
    def __init__(self, ):
        super(faced_train, self).__init__()
        self.channel_attention = CAM(32)  # Add ChannelAttention layer
        self.batch_norm = nn.BatchNorm1d(32)
        self.conv = nn.Conv1d(in_channels=32, out_channels=32, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2)
        self.dropout = nn.Dropout(p=0.2)
        hparams = {"backbone_activation": "silu",
                   "backbone_units": 64, "backbone_layers": 2, "backbone_dr": 0.5, "tau": 10,
                   "init": 1.35, "use_mixed": False, "no_gate": False, "minimal": False}
        self.cfc = Cfc(in_features=375, hidden_size=128, out_feature=64, hparams=hparams, return_sequences=False)
        self.output_layer = nn.Linear(64, 4)

    def forward(self, input):
        # Apply the ChannelAttention to the input
        attention_output, y = self.channel_attention(input)

        output_ = self.batch_norm(attention_output)
        output_ = self.conv(output_)
        output_ = self.pool(output_)
        output_ = self.dropout(output_)

        # Pass through the Cfc layer
        output = self.cfc(output_)
        output = self.output_layer(output)

        return output, y